/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtable;

/**
 *
 * @author 12133
 */
public class TestBST {

    //code for testing
    public static void main(String[] args) {
        //creating a hashtable
        BSTHashTable ht = new BSTHashTable();
        //adding squares of values between 1 and 10 to the hashtable (1,4,9,16,25,36,49,64,81)
        for (int i = 1; i <= 10; i++) {
            int value = i * i;
            ht.insert(new Node(value));
        }
        //displaying the hashtable
        ht.displayHashtable();
    }
}
