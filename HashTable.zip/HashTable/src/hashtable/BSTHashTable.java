/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtable;

/**
 *
 * @author 12133
 */
public class BSTHashTable {

    //using array of type BST
    BST[] hashtable;
    int size = 3;
    int numItems;

    public BSTHashTable() {
        hashtable = new BST[size]; //creating the hashtable
        for (int i = 0; i < size; i++) { //initialize each array slot
            hashtable[i] = new BST();
        }
    }

    public int hash(int key) {
        //fixed the code to avoid getting negative hash values
        return Math.abs(key % size);
    }

    //method to add a value to the hashtable.
   
    public void insert(Node value) {
        //hashing the value
        int index = hash(value.data);
        //checking if value is not present on the bst at index position
        if (hashtable[index].search(value.data) == null) {
            //adding value, updating numItems
            hashtable[index].insert(value.data);
            numItems++;
            //rehashing if load factor is greater than 0.75
            double loadFactor = (double) numItems / size;
            if (loadFactor > 0.75) {
                rehash();
            }
        }
    }

    public void delete(int value) {
        int index = hash(value);
        //decrementing numItems if delete method of BST at index position returned true for value
        if (hashtable[index].delete(value)) {
            numItems--;
        }

    }

    public Node find(int id) {
        int index = hash(id);
        //searching and returning the node if found, else null
        return hashtable[index].search(id);
    }

    public void displayHashtable() {
        for (int i = 0; i < size; i++) {
            if (hashtable[i] != null) {
                System.out.print(i + ": ");
                //printing the bst at index position using in order traversal
                hashtable[i].inorder();
                System.out.println();
            }
        }
    }

    private void rehash() {
        //store current hashtable in a temp location
        BST[] temp = hashtable;
        //System.arraycopy(hashtable,temp,0,0,size);
        hashtable = new BST[2 * size];
        //reinitialize hashtable
        for (int i = 0; i < 2 * size; i++) {
            hashtable[i] = new BST();
        }
        numItems = 0;
        size = size * 2;
        //call the insert again
        for (int i = 0; i < temp.length; i++) {
            //fetching node with minimum value from current bst
            Node curr = temp[i].min();
            //looping until curr is null
            while (curr != null) {
                //inserting the node in the new hashtable
                insert(curr);
                //deleting min node from bst
                temp[i].delete(curr.data);
                //fetching next min node from bst
                curr = temp[i].min();
            }
        }
    }
}
